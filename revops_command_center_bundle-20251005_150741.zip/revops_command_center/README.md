# RevOps Command Center

Draft scaffold for our flagship multi-CRM orchestration demo. This repo will simulate a real-world RevOps rescue: ingesting HubSpot, Salesforce, and Pipedrive data, normalizing it, scoring accounts, automating playbooks, and surfacing a cinematic dashboard + async handoff assets.

> Status: scaffold only — implementation forthcoming.

## Structure
- `orchestration/`: ingestion, normalization, scoring, and automation workflows.
- `api/`: FastAPI surface for the UI and external consumers.
- `ui/`: SvelteKit (or Next.js) frontend for the command dashboard.
- `data/`: sample datasets for HubSpot/Salesforce/Pipedrive.
- `notebooks/`: experiments for scoring logic & feature engineering.
- `tests/`: pytest suite (unit + integration) to keep the system honest.
- `docs/`: architecture notes, mission log, and playbooks for each segment.

## Next Steps
1. Define canonical schema + pydantic models.
2. Build ingestion adapters for each CRM sample dataset.
3. Implement scoring engine & automation orchestrator.
4. Flesh out dashboard UI + Notion/markdown playbooks.
5. Record case study walkthrough for portfolio.

## Demo Artifacts
-  — Markdown playbooks generated per run.
-  — async email digest sample.
-  — event log consumed by mission log preview.
-  — Svelte page pulling FastAPI data.
-  — snapshot generator for portfolio assets (run with ).
