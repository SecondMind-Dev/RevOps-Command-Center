
# Architecture Notes (Scaffold)

- Canonical schema defined in `orchestration/normalization/schema.py`.
- Adapters ingest data from CSV/API mocks into the canonical models.
- Scoring engine will support multiple missions (new business, expansion, churn).
- Automation runner will dispatch events to Slack/email/CRM connectors.
- API exposes aggregated views for the UI + Notion exporters.
