# Expansion Playbook (Draft)

To be populated by automation once scoring engine is live.
