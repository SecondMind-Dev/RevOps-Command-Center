from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from revops_command_center.orchestration.scoring.pipeline import Scorecard


@dataclass(slots=True)
class PlaybookGenerator:
    output_dir: Path

    def render(self, scorecard: Scorecard) -> None:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._write_hot_accounts(scorecard)
        self._write_warm_accounts(scorecard)

    def _write_hot_accounts(self, scorecard: Scorecard) -> None:
        path = self.output_dir / "hot_accounts.md"
        lines = [
            "# Hot Accounts",
            "",
            "These teams need action today:",
            "",
        ]
        for snapshot in scorecard.snapshots:
            if snapshot.label != "Hot":
                continue
            owner = snapshot.account.owner or "unassigned"
            lines.append(
                f"- **{snapshot.account.name}** — owner {owner} — score {snapshot.score}"
            )
        if len(lines) == 4:
            lines.append("_No hot accounts right now._")
        path.write_text("\n".join(lines))

    def _write_warm_accounts(self, scorecard: Scorecard) -> None:
        path = self.output_dir / "warm_accounts.md"
        lines = [
            "# Warm Accounts",
            "",
            "Prep these for nurture or check-ins:",
            "",
        ]
        for snapshot in scorecard.snapshots:
            if snapshot.label != "Warm":
                continue
            lines.append(f"- {snapshot.account.name} — score {snapshot.score}")
        if len(lines) == 4:
            lines.append("_No warm accounts right now._")
        path.write_text("\n".join(lines))
