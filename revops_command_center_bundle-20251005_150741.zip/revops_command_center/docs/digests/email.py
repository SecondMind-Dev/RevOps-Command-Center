from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from revops_command_center.orchestration.scoring.pipeline import Scorecard


@dataclass(slots=True)
class DigestGenerator:
    output_dir: Path

    def render(
        self, scorecard: Scorecard, *, generated_at: datetime | None = None
    ) -> Path:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        path = self.output_dir / "daily_digest.txt"
        timestamp = generated_at or datetime.now(timezone.utc)
        lines = [
            "RevOps Command Center Digest",
            f"Generated: {timestamp.astimezone(timezone.utc).isoformat()}",
            "",
        ]
        lines.append("Top Accounts (Score ≥ 0.6)")
        for snap in scorecard.snapshots:
            if snap.score < 0.6:
                continue
            owner = snap.account.owner or "unassigned"
            lines.append(f"- {snap.account.name} — {snap.score} — owner {owner}")
        if lines[-1] == "Top Accounts (Score ≥ 0.6)":
            lines.append("  none today")
        lines.append("")

        lines.append("Warm Queue (Score 0.3 – 0.6)")
        has_warm = False
        for snap in scorecard.snapshots:
            if 0.3 <= snap.score < 0.6:
                has_warm = True
                lines.append(f"- {snap.account.name} — {snap.score}")
        if not has_warm:
            lines.append("  none today")
        lines.append("")

        lines.extend(
            [
                "Action Reminders",
                "- Review automation log in revops_command_center/automation_log.jsonl",
                "- Refresh Notion playbooks in docs/playbooks/generated",
            ]
        )

        path.write_text("\n".join(lines))
        return path
