"""FastAPI app entrypoint stub."""

from __future__ import annotations

from fastapi import FastAPI

from .routers import accounts, dashboards, tasks

app = FastAPI(title="RevOps Command Center", version="0.1.0")

app.include_router(accounts.router)
app.include_router(dashboards.router)
app.include_router(tasks.router)


@app.get("/health", tags=["system"])
async def healthcheck() -> dict[str, str]:
    return {"status": "ok"}
