from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, WebSocket
from fastapi.responses import FileResponse

from revops_command_center.orchestration import pipeline

from ..live import manager

router = APIRouter(prefix="/dashboards", tags=["dashboards"])


def _build_payload() -> dict[str, Any]:
    bundle_url = "http://localhost:8000/dashboards/bundle"
    try:
        result = pipeline.run_orchestration()
        payload = pipeline.build_dashboard_payload(result)
        payload["using_cache"] = False
    except Exception as exc:  # pragma: no cover - expected for chaos tests
        logging.exception(
            "RevOps orchestration failed, falling back to cached payload",
            exc_info=exc,
        )
        cached = pipeline.load_cached_payload()
        if not cached:
            raise
        payload = cached
        payload["using_cache"] = True

    payload["artifact_bundle_url"] = bundle_url
    if "artifact_bundle" not in payload:
        payload["artifact_bundle"] = str((pipeline.BUNDLE_DIR / "latest.zip").resolve())
    pipeline.cache_payload(payload)
    return payload


@router.get("/exec")
async def exec_overview() -> dict[str, Any]:
    return _build_payload()


@router.post("/run")
async def run_mission() -> dict[str, Any]:
    payload = _build_payload()
    await manager.broadcast({"type": "refresh", "data": payload})
    return {"status": "ok", "data": payload}


@router.get("/bundle")
async def download_bundle() -> FileResponse:
    bundle_path = pipeline.BUNDLE_DIR / "latest.zip"
    if not bundle_path.exists():
        payload = _build_payload()
        bundle_path = Path(payload["artifact_bundle"])
    return FileResponse(
        path=bundle_path,
        media_type="application/zip",
        filename="revops_artifacts.zip",
    )


@router.websocket("/stream")
async def dashboard_stream(websocket: WebSocket) -> None:
    await manager.connect(websocket)
    try:
        await websocket.send_json(
            {
                "type": "welcome",
                "message": "Live updates armed. Trigger a mission run to refresh the dashboard.",
            }
        )
        await manager.listen(websocket)
    finally:
        manager.disconnect(websocket)
