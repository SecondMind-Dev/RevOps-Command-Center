from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from revops_command_center.orchestration import pipeline


def main() -> None:
    result = pipeline.run_orchestration()
    payload = {
        "captured_at": datetime.now(timezone.utc).isoformat(),
        "top_accounts": [
            {
                "id": snap.account.id,
                "name": snap.account.name,
                "owner": snap.account.owner,
                "label": snap.label,
                "score": snap.score,
            }
            for snap in result.scorecard.top_accounts(5)
        ],
        "mission_log": result.mission_log.entries,
    }

    output_dir = Path("revops_command_center/demo")
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / "dashboard_snapshot.json").write_text(json.dumps(payload, indent=2))
    print("Demo snapshot written to", output_dir)


if __name__ == "__main__":
    main()
