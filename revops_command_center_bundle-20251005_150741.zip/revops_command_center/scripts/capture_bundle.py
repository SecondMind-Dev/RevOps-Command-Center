from __future__ import annotations

import json
import shutil
import zipfile
from pathlib import Path

from revops_command_center.orchestration import pipeline


def main() -> None:
    result = pipeline.run_orchestration()

    snapshot_payload = {
        "captured_at": result.generated_at.isoformat(),
        "top_accounts": result.top_accounts,
        "mission_log": result.mission_log.entries,
        "kpis": result.kpis,
    }

    demo_dir = Path("revops_command_center/demo")
    demo_dir.mkdir(parents=True, exist_ok=True)
    (demo_dir / "dashboard_snapshot.json").write_text(
        json.dumps(snapshot_payload, indent=2),
        encoding="utf-8",
    )

    dest_root = Path("docs/SWEcho/portfolio/revops")
    dest_root.mkdir(parents=True, exist_ok=True)
    stamp = result.generated_at.strftime("%Y%m%d_%H%M%S")
    dest_dir = dest_root / stamp
    if dest_dir.exists():
        shutil.rmtree(dest_dir)
    dest_dir.mkdir(parents=True, exist_ok=False)

    bundle_path = result.bundle_path
    shutil.copy2(bundle_path, dest_dir / "revops_artifacts.zip")

    payload_path = pipeline.PAYLOAD_CACHE_PATH
    if payload_path.exists():
        shutil.copy2(payload_path, dest_dir / "payload.json")

    summary = {
        "generated_at": result.generated_at.isoformat(),
        "bundle_source": str(bundle_path.resolve()),
        "destination": str(dest_dir.resolve()),
        "kpis": result.kpis,
        "top_accounts": result.top_accounts,
    }
    (dest_dir / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )

    contents_dir = dest_dir / "bundle_contents"
    contents_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(bundle_path, mode="r") as archive:
        archive.extractall(contents_dir)

    print(f"Captured RevOps artifact pack → {dest_dir}")  # noqa: T201


if __name__ == "__main__":
    main()
