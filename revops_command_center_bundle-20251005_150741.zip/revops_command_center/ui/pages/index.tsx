import Head from "next/head";
import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  RadialBar,
  RadialBarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
} from "recharts";

const LOOM_EMBED_URL = "https://www.loom.com/embed/4f4ba2f4a3d84aa59a402b9bba9d7b9e";
const LOOM_SHARE_URL = LOOM_EMBED_URL.replace("/embed/", "/share/");

type Account = {
  id: string;
  name: string;
  owner?: string;
  label: string;
  score: number;
};

type Playbook = {
  name: string;
  content: string;
  path: string;
};

type Digest = {
  text: string;
  path: string;
  generated_at: string;
};

type KPIs = Record<string, number>;

type DashboardPayload = {
  top_accounts: Account[];
  mission_log_entries: string[];
  playbooks: Playbook[];
  digest: Digest;
  kpis: KPIs;
  artifact_bundle: string;
  artifact_bundle_url: string;
};

type RunResponse = {
  status: string;
  data: DashboardPayload;
};

type TabKey = "dashboard" | "playbooks" | "digest" | "mission";

const TABS: { key: TabKey; label: string }[] = [
  { key: "dashboard", label: "Dashboard" },
  { key: "playbooks", label: "Playbooks" },
  { key: "digest", label: "Daily Digest" },
  { key: "mission", label: "Mission Log" },
];

export default function Home() {
  const [data, setData] = useState<DashboardPayload | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<TabKey>("dashboard");
  const [isRunning, setIsRunning] = useState(false);
  const [runStatus, setRunStatus] = useState<string>("");
  const [flash, setFlash] = useState(false);
  const [playbookSearch, setPlaybookSearch] = useState("");
  const [missionSearch, setMissionSearch] = useState("");
  const [showTour, setShowTour] = useState(false);
  const [isLive, setIsLive] = useState(false);
  const [liveMessage, setLiveMessage] = useState<string | null>(null);
  const downloadUrl = data?.artifact_bundle_url ?? "http://localhost:8000/dashboards/bundle";

  async function loadData() {
    try {
      const response = await fetch("http://localhost:8000/dashboards/exec");
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const payload = (await response.json()) as DashboardPayload;
      setData(payload);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      setError(message);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    if (typeof window === "undefined") {
      return;
    }

    const protocol = window.location.protocol === "https:" ? "wss" : "ws";
    const host = window.location.hostname || "localhost";
    const ws = new WebSocket(`${protocol}://${host}:8000/dashboards/stream`);

    ws.onopen = () => {
      setIsLive(true);
    };

    ws.onclose = () => {
      setIsLive(false);
    };

    ws.onerror = () => {
      setIsLive(false);
    };

    ws.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data as string);
        if (message?.type === "welcome" && typeof message.message === "string") {
          setLiveMessage(message.message);
          return;
        }
        if (message?.type === "refresh" && message.data) {
          setData(message.data as DashboardPayload);
          setRunStatus(`Last run: ${new Date((message.data as DashboardPayload).digest.generated_at).toLocaleString()}`);
          setFlash(true);
          setTimeout(() => setFlash(false), 1500);
        }
      } catch (err) {
        console.warn("Live feed error", err);
      }
    };

    return () => {
      ws.close();
    };
  }, []);

  const kpiEntries = useMemo(() => {
    if (!data) return [];
    return Object.entries(data.kpis).map(([key, value]) => ({
      key,
      value: Number(value ?? 0),
    }));
  }, [data]);

  const filteredPlaybooks = useMemo(() => {
    if (!data) return [];
    if (!playbookSearch.trim()) return data.playbooks;
    const query = playbookSearch.toLowerCase();
    return data.playbooks.filter(
      (pb) =>
        pb.name.toLowerCase().includes(query) ||
        pb.content.toLowerCase().includes(query)
    );
  }, [data, playbookSearch]);

  const filteredMissionLog = useMemo(() => {
    if (!data) return [];
    if (!missionSearch.trim()) return data.mission_log_entries;
    const query = missionSearch.toLowerCase();
    return data.mission_log_entries.filter((entry) =>
      entry.toLowerCase().includes(query)
    );
  }, [data, missionSearch]);

  const scoreChartData = useMemo(() => {
    if (!data) return [];
    return data.top_accounts.map((account) => ({
      name: account.name,
      score: account.score,
    }));
  }, [data]);

  const labelBreakdown = useMemo(() => {
    if (!data) return [];
    const hot = Number(data.kpis.hot_accounts ?? 0);
    const warm = Number(data.kpis.warm_accounts ?? 0);
    const total = Number(data.kpis.total_accounts ?? hot + warm);
    const cooling = Math.max(total - hot - warm, 0);
    return [
      { name: "Hot", value: hot, fill: "#FF5068" },
      { name: "Warm", value: warm, fill: "#FFB347" },
      { name: "Cooling", value: cooling, fill: "#6F7CFF" },
    ];
  }, [data]);

  const { kpiSparkData, kpiScaleMode } = useMemo(() => {
    if (!kpiEntries.length) {
      return { kpiSparkData: [], kpiScaleMode: "linear" as const };
    }

    const values = kpiEntries.map((entry) => entry.value);
    const positives = values.filter((value) => value > 0);
    const max = Math.max(...values);
    const minPositive = positives.length ? Math.min(...positives) : 0;
    const shouldUseLogScale = positives.length > 0 && max / Math.max(minPositive, 1) >= 20;

    const transform = (value: number) => {
      if (shouldUseLogScale) {
        return value <= 0 ? 0 : Math.log10(value + 1);
      }
      return value;
    };

    const sparkData = kpiEntries.map(({ key, value }) => ({
      key,
      name: formatKpiKey(key),
      value: transform(value),
      actual: value,
    }));

    return {
      kpiSparkData: sparkData,
      kpiScaleMode: shouldUseLogScale ? "log" : "linear",
    };
  }, [kpiEntries]);

  async function handleRunMission() {
    try {
      setIsRunning(true);
      setRunStatus("Running mission…");
      const response = await fetch("http://localhost:8000/dashboards/run", {
        method: "POST",
      });
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      const payload = (await response.json()) as RunResponse;
      setData(payload.data);
      setRunStatus(
        `Last run: ${new Date(payload.data.digest.generated_at).toLocaleString()}`
      );
      setFlash(true);
      setTimeout(() => setFlash(false), 1500);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unknown error";
      setRunStatus(`Mission failed: ${message}`);
    } finally {
      setIsRunning(false);
    }
  }

  if (error) {
    return (
      <main style={styles.main}>
        <Hero
          title="RevOps Command Center"
          subtitle="Unified signal radar across HubSpot, Salesforce, and Pipedrive."
          onRun={handleRunMission}
          runStatus={runStatus}
          isRunning={isRunning}
          onToggleTour={() => setShowTour((prev) => !prev)}
          downloadUrl={downloadUrl}
          isLive={isLive}
          liveMessage={liveMessage}
        />
        <p style={styles.error}>API error: {error}</p>
      </main>
    );
  }

  if (!data) {
    return (
      <main style={styles.main}>
        <Hero
          title="RevOps Command Center"
          subtitle="Unified signal radar across HubSpot, Salesforce, and Pipedrive."
          onRun={handleRunMission}
          runStatus={runStatus}
          isRunning={isRunning}
          onToggleTour={() => setShowTour((prev) => !prev)}
          downloadUrl={downloadUrl}
          isLive={isLive}
          liveMessage={liveMessage}
        />
        <p style={styles.loading}>Loading dashboard…</p>
      </main>
    );
  }

  return (
    <>
      <Head>
        <title>RevOps Command Center</title>
        <meta name="description" content="Proof Pulse RevOps dashboard" />
      </Head>
      <main style={styles.main}>
        <Hero
          title="RevOps Command Center"
          subtitle="Unified signal radar across HubSpot, Salesforce, and Pipedrive."
          onRun={handleRunMission}
          runStatus={runStatus || `Last run: ${new Date(data.digest.generated_at).toLocaleString()}`}
        isRunning={isRunning}
        onToggleTour={() => setShowTour((prev) => !prev)}
        downloadUrl={downloadUrl}
        isLive={isLive}
        liveMessage={liveMessage}
      />

      {showTour && <TourOverlay onClose={() => setShowTour(false)} />}

      <Tabs activeTab={activeTab} onSelect={setActiveTab} />

      {activeTab === "dashboard" && (
        <section style={styles.panel}>
          <h2 style={styles.heading}>Pipeline Snapshot</h2>
          <div style={styles.kpiGrid}>
            {kpiEntries.map(({ key, value }) => (
              <div
                key={key}
                style={{
                  ...styles.kpiCard,
                  ...(flash ? styles.flash : {}),
                }}
              >
                <span style={styles.kpiLabel}>{formatKpiKey(key)}</span>
                <span style={styles.kpiValue}>{value}</span>
              </div>
            ))}
          </div>

          <h3 style={styles.subheading}>Hot &amp; Warm Accounts</h3>
          <ul style={styles.list}>
            {data.top_accounts.map((account) => (
              <li
                key={account.id}
                style={{
                  ...styles.card,
                  ...(flash ? styles.flash : {}),
                }}
              >
                <div style={styles.cardHeader}>
                  <span style={styles.cardName}>{account.name}</span>
                  <span style={{ ...styles.badge, ...badgeFor(account.label) }}>
                    {account.label}
                  </span>
                </div>
                <p style={styles.cardMeta}>
                  Owner: {account.owner || "Unassigned"} · Score: {account.score}
                </p>
              </li>
            ))}
          </ul>

          <div style={styles.chartGrid}>
            <div style={styles.chartCard}>
              <header style={styles.chartHeader}>
                <h3 style={styles.chartTitle}>Account Heat Scores</h3>
                <span style={styles.chartMeta}>Top performers from the latest scan</span>
              </header>
              <div style={styles.chartBody}>
                <ResponsiveContainer width="100%" height={240}>
                  <BarChart data={scoreChartData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(154,165,255,0.15)" />
                    <XAxis dataKey="name" stroke="#9AA5FF" tick={{ fontSize: 12 }} interval={0} angle={-15} dy={10} />
                    <Tooltip
                      contentStyle={{
                        background: "rgba(12,13,30,0.95)",
                        border: "1px solid rgba(98,108,255,0.35)",
                        borderRadius: 12,
                        color: "#FAFBFF",
                      }}
                    />
                    <Bar dataKey="score" fill="#6F7CFF" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div style={styles.chartCard}>
              <header style={styles.chartHeader}>
                <h3 style={styles.chartTitle}>Pipeline Blend</h3>
                <span style={styles.chartMeta}>Hot vs Warm vs Cooling accounts</span>
              </header>
              <div style={styles.chartBody}>
                <ResponsiveContainer width="100%" height={240}>
                  <RadialBarChart
                    cx="50%"
                    cy="50%"
                    innerRadius="20%"
                    outerRadius="80%"
                    barSize={18}
                    data={labelBreakdown}
                  >
                    <RadialBar
                      background
                      dataKey="value"
                      cornerRadius={10}
                    />
                    <Tooltip
                      contentStyle={{
                        background: "rgba(12,13,30,0.95)",
                        border: "1px solid rgba(98,108,255,0.35)",
                        borderRadius: 12,
                        color: "#FAFBFF",
                      }}
                    />
                  </RadialBarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <div style={styles.chartRow}>
            <div style={styles.chartCardWide}>
              <header style={styles.chartHeader}>
                <h3 style={styles.chartTitle}>KPI Pulse</h3>
                <span style={styles.chartMeta}>
                  Every metric from this run at a glance
                  {kpiScaleMode === "log" ? " (log scale view)" : ""}
                </span>
              </header>
              <div style={styles.chartBody}>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={kpiSparkData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(154,165,255,0.12)" />
                    <XAxis dataKey="name" stroke="#9AA5FF" tick={{ fontSize: 12 }} interval={0} angle={-10} dy={10} />
                    <Tooltip
                      contentStyle={{
                        background: "rgba(12,13,30,0.95)",
                        border: "1px solid rgba(98,108,255,0.35)",
                        borderRadius: 12,
                        color: "#FAFBFF",
                      }}
                      formatter={(_value: number | string, _name: string, item) => {
                        const actual = item?.payload?.actual;
                        const numeric = typeof actual === "number" ? actual : Number(actual ?? 0);
                        return [numeric.toLocaleString(), ""];
                      }}
                    />
                    <Bar dataKey="value" fill="#8E9CFF" radius={[8, 8, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>

          <section style={styles.ctaPanel}>
            <div style={styles.ctaContent}>
              <h3 style={styles.ctaTitle}>Proof Pulse Activation Pack</h3>
              <p style={styles.ctaBlurb}>
                Download the artifact bundle, watch the Loom walkthrough, and tap in if you want this wired into your own revenue stack.
              </p>
            </div>
            <div style={styles.ctaLayout}>
              <div style={styles.loomBlock}>
                <div style={styles.loomFrameWrap}>
                  <iframe
                    src={`${LOOM_EMBED_URL}?hide_owner=true&hide_title=true&hideEmbedTopBar=true`}
                    style={styles.loomIframe as CSSProperties}
                    allowFullScreen
                    frameBorder="0"
                    title="RevOps Command Center Walkthrough"
                  />
                </div>
                <p style={styles.loomCaption}>15-minute fly-through showing the dashboard running against sample HubSpot + Salesforce data.</p>
              </div>
              <div style={styles.ctaActions}>
                <a style={styles.downloadButton} href={downloadUrl} target="_blank" rel="noreferrer">
                  Download Full Pack
                </a>
                <a
                  style={styles.secondaryButton}
                  href={LOOM_SHARE_URL}
                  target="_blank"
                  rel="noreferrer"
                >
                  Open Loom in Tab
                </a>
                <a
                  style={styles.secondaryButton}
                  href="mailto:caleb@secondmind.co?subject=RevOps%20Command%20Center%20Inquiry"
                >
                  Contact Caleb
                </a>
              </div>
            </div>
          </section>
        </section>
      )}

      {activeTab === "playbooks" && (
        <section style={styles.panel}>
          <div style={styles.tabHeaderRow}>
            <h2 style={styles.heading}>Playbooks</h2>
            <input
              style={styles.searchInput}
              placeholder="Search playbooks"
              value={playbookSearch}
              onChange={(event) => setPlaybookSearch(event.target.value)}
            />
          </div>
          <p style={styles.sectionIntro}>
            Auto-generated action plans based on the latest RevOps sprint. These update every time the mission runs.
          </p>
          <div style={styles.playbookGrid}>
            {filteredPlaybooks.map((playbook) => (
              <article key={playbook.path} style={styles.playbookCard}>
                <header style={styles.playbookHeader}>
                  <h3 style={styles.playbookTitle}>{playbook.name}</h3>
                  <a style={styles.playbookLink} href={`vscode://file/${playbook.path}`}>
                    Open
                  </a>
                </header>
                <pre style={styles.playbookBody}>{playbook.content}</pre>
              </article>
            ))}
            {filteredPlaybooks.length === 0 && (
              <p style={styles.emptyState}>No playbooks match your search.</p>
            )}
          </div>
        </section>
      )}

      {activeTab === "digest" && (
        <section style={styles.panel}>
          <div style={styles.tabHeaderRow}>
            <h2 style={styles.heading}>Daily Digest</h2>
            <span style={styles.digestMeta}>
              Generated {new Date(data.digest.generated_at).toLocaleString()} · Source: {data.digest.path}
            </span>
          </div>
          <article style={styles.digestBox}>
            {data.digest.text.split("\n\n").map((paragraph, idx) => (
              <p key={idx} style={styles.digestParagraph}>
                {paragraph}
              </p>
            ))}
          </article>
        </section>
      )}

      {activeTab === "mission" && (
        <section style={styles.panel}>
          <div style={styles.tabHeaderRow}>
            <h2 style={styles.heading}>Automation Timeline</h2>
            <input
              style={styles.searchInput}
              placeholder="Search mission log"
              value={missionSearch}
              onChange={(event) => setMissionSearch(event.target.value)}
            />
          </div>
          <p style={styles.sectionIntro}>
            Full mission log from the latest run. Each entry captures the automation step, target entity, and payload details.
          </p>
          <ul style={styles.logList}>
            {filteredMissionLog.length === 0 && (
              <li style={styles.emptyState}>No mission entries match your search.</li>
            )}
            {filteredMissionLog.map((entry, index) => (
              <li key={`${entry}-${index}`} style={styles.logEntry}>
                {entry}
              </li>
            ))}
          </ul>
        </section>
      )}
      </main>
    </>
  );
}

function Tabs({ activeTab, onSelect }: { activeTab: TabKey; onSelect: (tab: TabKey) => void }) {
  return (
    <nav style={styles.tabs}>
      {TABS.map((tab) => (
        <button
          key={tab.key}
          type="button"
          onClick={() => onSelect(tab.key)}
          style={{
            ...styles.tabButton,
            ...(tab.key === activeTab ? styles.tabButtonActive : {}),
          }}
        >
          {tab.label}
        </button>
      ))}
    </nav>
  );
}

function Hero({
  title,
  subtitle,
  onRun,
  runStatus,
  isRunning,
  onToggleTour,
  downloadUrl,
  isLive,
  liveMessage,
}: {
  title: string;
  subtitle: string;
  onRun: () => Promise<void>;
  runStatus: string;
  isRunning: boolean;
  onToggleTour: () => void;
  downloadUrl: string;
  isLive: boolean;
  liveMessage: string | null;
}) {
  return (
    <section style={styles.hero}>
      <h1 style={styles.title}>{title}</h1>
      <p style={styles.subtitle}>{subtitle}</p>
      <div style={styles.heroActions}>
        <button
          style={{
            ...styles.runButton,
            ...(isRunning ? styles.runButtonDisabled : {}),
          }}
          type="button"
          onClick={onRun}
          disabled={isRunning}
        >
          {isRunning ? "Running…" : "Run Demo Mission"}
        </button>
        <a style={styles.downloadButton} href={downloadUrl} target="_blank" rel="noreferrer">
          Download Pack
        </a>
        <button style={styles.tourButton} type="button" onClick={onToggleTour}>
          Guided Tour
        </button>
        {runStatus && <span style={styles.runStatus}>{runStatus}</span>}
      </div>
      <div style={styles.heroMeta}>
        <span
          style={{
            ...styles.liveBadge,
            ...(isLive ? styles.liveBadgeActive : styles.liveBadgeIdle),
          }}
        >
          <span
            style={{
              ...styles.liveDot,
              background: isLive ? "#FF5C5C" : "#555B7A",
              boxShadow: isLive ? "0 0 16px rgba(255,92,92,0.6)" : "none",
            }}
          />
          {isLive ? "Live sync on" : "Live sync idle"}
        </span>
        {liveMessage && <span style={styles.liveMessage}>{liveMessage}</span>}
      </div>
    </section>
  );
}

function TourOverlay({ onClose }: { onClose: () => void }) {
  return (
    <div style={styles.tourOverlay}>
      <div style={styles.tourCard}>
        <button style={styles.tourClose} type="button" onClick={onClose}>
          Close Tour
        </button>
        <h2 style={{ margin: 0, fontSize: "22px" }}>Here’s the play:</h2>
        <ul style={styles.tourList}>
          <li style={styles.tourListItem}>
            Dashboard tab = live KPI cards + heat charts. Watch the bars spike when you rerun the mission.
          </li>
          <li style={styles.tourListItem}>
            Playbooks tab = the exact markdown sequences the automation ships; filter to inspect for any niche.
          </li>
          <li style={styles.tourListItem}>
            Daily Digest = client-ready briefing copy you copy/paste straight into email or Slack.
          </li>
          <li style={styles.tourListItem}>
            Mission Log = forensic trail of every automation step in chronological order.
          </li>
          <li style={styles.tourListItem}>
            Smash “Download Pack” for the full ZIP (playbooks, digest, logs) to hand prospects receipts.
          </li>
        </ul>
      </div>
    </div>
  );
}

const styles: Record<string, CSSProperties> = {
  main: {
    minHeight: "100vh",
    background: "#050508",
    color: "#FAFBFF",
    padding: "48px 32px",
    fontFamily: "Inter, sans-serif",
    display: "flex",
    flexDirection: "column",
    gap: "24px",
    overflowX: "hidden",
    boxSizing: "border-box",
  },
  hero: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
  },
  title: {
    margin: 0,
    fontSize: "48px",
    letterSpacing: "-1px",
  },
  subtitle: {
    margin: 0,
    color: "#9AA5FF",
    maxWidth: "520px",
  },
  heroActions: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
    marginTop: "12px",
  },
  runButton: {
    borderRadius: "999px",
    border: "1px solid rgba(98,108,255,0.45)",
    background: "rgba(98,108,255,0.2)",
    color: "#FAFBFF",
    padding: "10px 22px",
    fontSize: "14px",
    cursor: "pointer",
    transition: "transform 0.2s ease, box-shadow 0.2s ease",
    minHeight: "44px",
    display: "inline-flex",
    alignItems: "center",
  },
  runButtonDisabled: {
    opacity: 0.6,
    cursor: "not-allowed",
    boxShadow: "none",
  },
  downloadButton: {
    borderRadius: "999px",
    border: "1px solid rgba(80,90,255,0.35)",
    background: "rgba(12,13,30,0.7)",
    color: "#FAFBFF",
    padding: "9px 20px",
    fontSize: "13px",
    textDecoration: "none",
    transition: "transform 0.2s ease, box-shadow 0.2s ease",
    minHeight: "44px",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    whiteSpace: "nowrap",
    maxWidth: "260px",
    flexShrink: 0,
  },
  tourButton: {
    borderRadius: "999px",
    border: "1px solid rgba(154,165,255,0.35)",
    background: "transparent",
    color: "#9AA5FF",
    padding: "9px 18px",
    fontSize: "13px",
    cursor: "pointer",
    minHeight: "44px",
    display: "inline-flex",
    alignItems: "center",
  },
  runStatus: {
    fontSize: "13px",
    color: "#B2B8FF",
  },
  heroMeta: {
    display: "flex",
    alignItems: "center",
    gap: "12px",
    marginTop: "10px",
  },
  liveBadge: {
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
    borderRadius: "999px",
    padding: "4px 12px",
    fontSize: "12px",
    letterSpacing: "0.6px",
    textTransform: "uppercase",
  },
  liveBadgeActive: {
    background: "rgba(255,92,92,0.15)",
    color: "#FF8A8A",
    border: "1px solid rgba(255,92,92,0.45)",
  },
  liveBadgeIdle: {
    background: "rgba(90,110,255,0.12)",
    color: "#8E9CFF",
    border: "1px solid rgba(90,110,255,0.3)",
  },
  liveDot: {
    width: "8px",
    height: "8px",
    borderRadius: "50%",
  },
  liveMessage: {
    fontSize: "12px",
    color: "#B2B8FF",
  },
  tabs: {
    display: "flex",
    gap: "12px",
  },
  tabButton: {
    border: "1px solid rgba(98,108,255,0.2)",
    background: "rgba(12,13,30,0.6)",
    color: "#FAFBFF",
    borderRadius: "999px",
    padding: "8px 18px",
    fontSize: "14px",
    cursor: "pointer",
  },
  tabButtonActive: {
    background: "rgba(98,108,255,0.35)",
    borderColor: "rgba(98,108,255,0.6)",
  },
  panel: {
    background: "linear-gradient(145deg, rgba(16,18,40,0.85), rgba(12,13,30,0.95))",
    borderRadius: "16px",
    border: "1px solid rgba(98,108,255,0.2)",
    padding: "24px",
    boxShadow: "0 18px 60px -30px rgba(0,0,0,0.8)",
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    maxWidth: "100%",
    boxSizing: "border-box",
  },
  heading: {
    margin: 0,
    textTransform: "uppercase",
    letterSpacing: "0.5px",
    fontSize: "14px",
    color: "#8E9CFF",
  },
  subheading: {
    margin: "8px 0 12px",
    fontSize: "16px",
    fontWeight: 600,
  },
  tabHeaderRow: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "12px",
    flexWrap: "wrap",
  },
  list: {
    listStyle: "none",
    margin: 0,
    padding: 0,
    display: "grid",
    gap: "16px",
  },
  card: {
    background: "rgba(3,5,18,0.7)",
    borderRadius: "14px",
    border: "1px solid rgba(90,110,255,0.15)",
    padding: "20px",
    transition: "box-shadow 0.3s ease",
  },
  cardHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "12px",
    marginBottom: "6px",
  },
  cardName: {
    fontSize: "18px",
    fontWeight: 600,
  },
  cardMeta: {
    margin: 0,
    color: "#B2B8FF",
    fontSize: "14px",
  },
  badge: {
    padding: "4px 10px",
    borderRadius: "999px",
    fontSize: "11px",
    letterSpacing: "0.8px",
    textTransform: "uppercase",
  },
  flash: {
    boxShadow: "0 0 30px rgba(126,143,255,0.4)",
  },
  logList: {
    listStyle: "none",
    margin: 0,
    padding: 0,
    display: "grid",
    gap: "8px",
  },
  logEntry: {
    fontFamily: "IBM Plex Mono, monospace",
    fontSize: "12px",
    borderRadius: "10px",
    border: "1px solid rgba(126,143,255,0.35)",
    padding: "12px 16px",
    background: "rgba(6,8,20,0.9)",
  },
  emptyState: {
    fontSize: "12px",
    color: "#B2B8FF",
    opacity: 0.8,
  },
  loading: {
    color: "#B2B8FF",
  },
  error: {
    color: "#FF7A7A",
  },
  sectionIntro: {
    margin: "0 0 8px",
    color: "#B2B8FF",
    fontSize: "13px",
  },
  playbookGrid: {
    display: "grid",
    gap: "16px",
  },
  playbookCard: {
    border: "1px solid rgba(98,108,255,0.25)",
    borderRadius: "12px",
    background: "rgba(12,13,30,0.9)",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  playbookHeader: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: "12px",
  },
  playbookTitle: {
    margin: 0,
    fontSize: "16px",
  },
  playbookLink: {
    color: "#9AA5FF",
    fontSize: "12px",
    textDecoration: "underline",
  },
  playbookBody: {
    margin: 0,
    fontFamily: "IBM Plex Mono, monospace",
    fontSize: "12px",
    lineHeight: 1.6,
    whiteSpace: "pre-wrap",
  },
  digestBox: {
    background: "rgba(6,8,20,0.9)",
    border: "1px solid rgba(126,143,255,0.3)",
    borderRadius: "12px",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  digestParagraph: {
    margin: 0,
    lineHeight: 1.7,
  },
  digestMeta: {
    color: "#B2B8FF",
    fontSize: "12px",
  },
  kpiGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))",
    gap: "12px",
  },
  kpiCard: {
    borderRadius: "12px",
    border: "1px solid rgba(90,110,255,0.25)",
    padding: "12px 16px",
    background: "rgba(12,13,30,0.85)",
    display: "flex",
    flexDirection: "column",
    gap: "4px",
    transition: "box-shadow 0.3s ease",
  },
  kpiLabel: {
    fontSize: "12px",
    textTransform: "uppercase",
    color: "#9AA5FF",
    letterSpacing: "0.6px",
  },
  kpiValue: {
    fontSize: "22px",
    fontWeight: 600,
  },
  searchInput: {
    borderRadius: "999px",
    border: "1px solid rgba(90,110,255,0.3)",
    padding: "8px 14px",
    background: "rgba(12,13,30,0.6)",
    color: "#FAFBFF",
    minWidth: "200px",
  },
  chartGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))",
    gap: "16px",
  },
  chartRow: {
    display: "flex",
    flexDirection: "column",
    marginTop: "12px",
  },
  chartCard: {
    borderRadius: "16px",
    border: "1px solid rgba(98,108,255,0.2)",
    background: "rgba(8,10,24,0.85)",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  chartCardWide: {
    borderRadius: "16px",
    border: "1px solid rgba(98,108,255,0.2)",
    background: "rgba(8,10,24,0.85)",
    padding: "20px",
    display: "flex",
    flexDirection: "column",
    gap: "12px",
  },
  chartHeader: {
    display: "flex",
    flexDirection: "column",
    gap: "4px",
  },
  chartTitle: {
    margin: 0,
    fontSize: "16px",
  },
  chartMeta: {
    fontSize: "12px",
    color: "#B2B8FF",
  },
  chartBody: {
    height: "100%",
  },
  ctaPanel: {
    marginTop: "16px",
    borderRadius: "18px",
    border: "1px solid rgba(154,165,255,0.35)",
    background: "linear-gradient(135deg, rgba(17,20,60,0.9), rgba(12,13,30,0.9))",
    padding: "24px",
    display: "flex",
    flexDirection: "column",
    gap: "18px",
  },
  ctaContent: {
    display: "flex",
    flexDirection: "column",
    gap: "8px",
  },
  ctaTitle: {
    margin: 0,
    fontSize: "20px",
  },
  ctaBlurb: {
    margin: 0,
    color: "#B2B8FF",
    fontSize: "14px",
    maxWidth: "480px",
  },
  ctaActions: {
    display: "flex",
    flexWrap: "wrap",
    gap: "12px",
    justifyContent: "flex-start",
    alignItems: "flex-start",
  },
  secondaryButton: {
    borderRadius: "999px",
    border: "1px solid rgba(154,165,255,0.35)",
    background: "rgba(12,13,30,0.6)",
    color: "#FAFBFF",
    padding: "9px 18px",
    fontSize: "13px",
    textDecoration: "none",
    minHeight: "44px",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    whiteSpace: "nowrap",
    maxWidth: "240px",
    flexShrink: 0,
  },
  ctaLayout: {
    display: "flex",
    flexWrap: "wrap",
    gap: "18px",
  },
  loomBlock: {
    flex: "1 1 320px",
    display: "flex",
    flexDirection: "column",
    gap: "10px",
  },
  loomFrameWrap: {
    position: "relative",
    paddingBottom: "56.25%",
    borderRadius: "16px",
    overflow: "hidden",
    border: "1px solid rgba(98,108,255,0.25)",
    background: "#0a0c1f",
  },
  loomIframe: {
    position: "absolute",
    top: 0,
    left: 0,
    width: "100%",
    height: "100%",
  },
  loomCaption: {
    fontSize: "12px",
    color: "#B2B8FF",
    margin: 0,
  },
  tourOverlay: {
    position: "fixed",
    inset: 0,
    background: "rgba(5,6,14,0.92)",
    backdropFilter: "blur(12px)",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 1000,
    padding: "24px",
  },
  tourCard: {
    background: "rgba(12,13,30,0.95)",
    borderRadius: "20px",
    border: "1px solid rgba(98,108,255,0.3)",
    padding: "28px",
    maxWidth: "520px",
    display: "flex",
    flexDirection: "column",
    gap: "16px",
    color: "#FAFBFF",
  },
  tourList: {
    margin: 0,
    paddingLeft: "18px",
    display: "flex",
    flexDirection: "column",
    gap: "8px",
  },
  tourListItem: {
    fontSize: "14px",
    color: "#B2B8FF",
  },
  tourClose: {
    alignSelf: "flex-end",
    borderRadius: "999px",
    border: "1px solid rgba(98,108,255,0.4)",
    background: "rgba(12,13,30,0.8)",
    color: "#FAFBFF",
    padding: "8px 16px",
    fontSize: "13px",
    cursor: "pointer",
  },
};

function badgeFor(label: string): CSSProperties {
  if (label === "Hot") {
    return { background: "rgba(255, 99, 132, 0.2)", color: "#FF5068" };
  }
  if (label === "Warm") {
    return { background: "rgba(255, 206, 86, 0.2)", color: "#FFB347" };
  }
  return { background: "rgba(90, 110, 255, 0.25)", color: "#9AA5FF" };
}

function formatKpiKey(key: string): string {
  return key
    .split("_")
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}
