# UI Scaffold

SvelteKit/Next.js frontend placeholder for the RevOps Command Center dashboard.
