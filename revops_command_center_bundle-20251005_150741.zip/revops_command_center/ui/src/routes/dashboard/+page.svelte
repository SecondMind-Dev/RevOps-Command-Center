<script lang="ts">
  import { onMount } from "svelte";

  type Account = {
    id: string;
    name: string;
    owner?: string;
    label: string;
    score: number;
  };

  type DashboardPayload = {
    top_accounts: Account[];
    mission_log_preview: string[];
  };

  let data: DashboardPayload | null = null;
  let loading = true;
  let error: string | null = null;

  onMount(async () => {
    try {
      const res = await fetch("http://localhost:8000/dashboards/exec");
      if (!res.ok) {
        throw new Error(`HTTP ${res.status}`);
      }
      data = await res.json();
    } catch (err) {
      error = err instanceof Error ? err.message : "Unknown error";
    } finally {
      loading = false;
    }
  });
</script>

<svelte:head>
  <title>RevOps Command Center</title>
</svelte:head>

{#if loading}
  <div class="loading">Loading dashboard…</div>
{:else if error}
  <div class="error">{error}</div>
{:else if data}
  <main>
    <section class="hero">
      <h1>RevOps Command Center</h1>
      <p>Unified signal radar across HubSpot, Salesforce, and Pipedrive.</p>
    </section>

    <section class="panel">
      <h2>Hot &amp; Warm Accounts</h2>
      <div class="cards">
        {#each data.top_accounts as account}
          <article class="card" data-label={account.label}>
            <header>
              <h3>{account.name}</h3>
              <span class="label">{account.label}</span>
            </header>
            <p class="score">Score: {account.score}</p>
            <p class="owner">Owner: {account.owner ?? "Unassigned"}</p>
          </article>
        {/each}
      </div>
    </section>

    <section class="panel">
      <h2>Mission Log Preview</h2>
      <ul class="log">
        {#each data.mission_log_preview as entry}
          <li>{entry}</li>
        {/each}
      </ul>
    </section>
  </main>
{/if}

<style>
  :global(body) {
    margin: 0;
    font-family: "Inter", system-ui;
    background: #050508;
    color: #fafbff;
  }

  main {
    max-width: 1100px;
    margin: 0 auto;
    padding: 48px 24px 120px;
    display: flex;
    flex-direction: column;
    gap: 48px;
  }

  .hero {
    display: flex;
    flex-direction: column;
    gap: 8px;
  }

  .hero h1 {
    font-size: 48px;
    letter-spacing: -1px;
    margin: 0;
  }

  .hero p {
    margin: 0;
    color: #9aa5ff;
  }

  .panel {
    background: linear-gradient(145deg, rgba(16, 18, 40, 0.8), rgba(12, 13, 30, 0.9));
    border: 1px solid rgba(98, 108, 255, 0.2);
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 18px 60px -30px rgba(0, 0, 0, 0.8);
  }

  .panel h2 {
    margin: 0 0 16px;
    letter-spacing: 0.5px;
    text-transform: uppercase;
    font-size: 14px;
    color: #8e9cff;
  }

  .cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 16px;
  }

  .card {
    background: rgba(3, 5, 18, 0.7);
    border-radius: 14px;
    padding: 20px;
    border: 1px solid rgba(90, 110, 255, 0.15);
    display: flex;
    flex-direction: column;
    gap: 8px;
    transition: transform 160ms ease, border-color 160ms ease;
  }

  .card[data-label="Hot"] {
    border-color: rgba(255, 99, 132, 0.45);
    box-shadow: 0 0 12px rgba(255, 99, 132, 0.25);
  }

  .card:hover {
    transform: translateY(-4px);
    border-color: rgba(126, 143, 255, 0.4);
  }

  .card header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
  }

  .card h3 {
    margin: 0;
    font-size: 18px;
  }

  .score {
    font-size: 16px;
    margin: 0;
  }

  .owner {
    margin: 0;
    color: #b2b8ff;
  }

  .label {
    font-size: 12px;
    padding: 4px 10px;
    border-radius: 999px;
    background: rgba(87, 103, 255, 0.25);
    text-transform: uppercase;
    letter-spacing: 0.8px;
  }

  .log {
    list-style: none;
    margin: 0;
    padding: 0;
    display: grid;
    gap: 8px;
  }

  .log li {
    background: rgba(6, 8, 20, 0.9);
    padding: 12px 16px;
    border-radius: 10px;
    font-family: "IBM Plex Mono", monospace;
    font-size: 12px;
    color: #c3c8ff;
    border: 1px solid rgba(126, 143, 255, 0.2);
  }

  .loading,
  .error {
    padding: 120px 24px;
    text-align: center;
    font-size: 18px;
    color: #b7c0ff;
  }

  .error {
    color: #ff7a7a;
  }
</style>
