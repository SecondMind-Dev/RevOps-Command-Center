from __future__ import annotations

import pytest

pytest.importorskip("fastapi")
pytest.importorskip("fastapi.testclient")

from fastapi.testclient import TestClient

from revops_command_center.api.main import app


def test_exec_dashboard_endpoint() -> None:
    client = TestClient(app)
    response = client.get("/dashboards/exec")
    assert response.status_code == 200
    data = response.json()
    assert "top_accounts" in data
    assert "playbooks" in data
    assert "digest" in data
    assert "mission_log_entries" in data


def test_run_dashboard_endpoint() -> None:
    client = TestClient(app)
    response = client.post("/dashboards/run")
    assert response.status_code == 200
    payload = response.json()
    assert payload["status"] == "ok"
    assert "data" in payload
    data = payload["data"]
    assert "top_accounts" in data
    assert "digest" in data


def test_dashboard_stream_pushes_updates() -> None:
    client = TestClient(app)
    with client.websocket_connect("/dashboards/stream") as websocket:
        welcome = websocket.receive_json()
        assert welcome["type"] == "welcome"
        response = client.post("/dashboards/run")
        assert response.status_code == 200
        refresh = websocket.receive_json()
        assert refresh["type"] == "refresh"
        assert "data" in refresh
