from __future__ import annotations

import csv
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from ..normalization import merge
from ..normalization.schema import Activity, Account, Deal
from .adapters import (
    ActivityAdapter,
    HubSpotAccountAdapter,
    PipedriveDealAdapter,
    SalesforceAccountAdapter,
)

DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"


@dataclass(slots=True)
class RawDataBundle:
    accounts: list[Account]
    deals_by_account: dict[str, list[Deal]]
    activities_by_account: dict[str, list[Activity]]


def load_csv(path: Path) -> Iterable[dict[str, str]]:
    with path.open(newline="") as handle:
        reader = csv.DictReader(handle)
        yield from reader


def load_accounts() -> list[Account]:
    accounts: list[Account] = []

    hubspot_path = DATA_DIR / "hubspot_sample.csv"
    salesforce_path = DATA_DIR / "salesforce_sample.csv"

    for row in load_csv(hubspot_path):
        accounts.append(HubSpotAccountAdapter(row).to_account())

    for row in load_csv(salesforce_path):
        accounts.append(SalesforceAccountAdapter(row).to_account())

    return accounts


def load_deals(domain_to_account_id: dict[str, str]) -> dict[str, list[Deal]]:
    pipedrive_path = DATA_DIR / "pipedrive_sample.csv"
    deals: dict[str, list[Deal]] = defaultdict(list)
    for row in load_csv(pipedrive_path):
        domain = row.get("org_name", "").replace(" ", "").lower() or None
        account_id = None
        if domain and domain in domain_to_account_id:
            account_id = domain_to_account_id[domain]
        else:
            name = row.get("org_name", "").strip().lower()
            account_id = domain_to_account_id.get(name)
        if not account_id:
            # skip deal for now if we cannot match
            continue
        deals[account_id].append(PipedriveDealAdapter(row).to_deal(account_id))
    return deals


def load_activities(domain_to_account_id: dict[str, str]) -> dict[str, list[Activity]]:
    activities_path = DATA_DIR / "activities_sample.csv"
    activities: dict[str, list[Activity]] = defaultdict(list)
    for row in load_csv(activities_path):
        domain = row.get("account_name", "").replace(" ", "").lower()
        account_id = domain_to_account_id.get(domain)
        if not account_id:
            continue
        activities[account_id].append(ActivityAdapter(row).to_activity(account_id))
    return activities


def load_bundle() -> merge.CanonicalGraph:
    accounts = load_accounts()
    graph = merge.build_canonical_graph(accounts)

    deals = load_deals(graph.domain_index)
    activities = load_activities(graph.domain_index)

    graph.attach_related(deals=deals, activities=activities)
    return graph
