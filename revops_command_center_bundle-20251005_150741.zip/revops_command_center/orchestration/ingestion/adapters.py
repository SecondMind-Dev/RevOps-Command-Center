"""Adapters that transform CRM payloads into the canonical schema."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from ..normalization.schema import Activity, Account, Deal

ISO_FORMATS = (
    "%Y-%m-%dT%H:%M:%S%z",
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%d",
    "%Y-%m-%d %H:%M:%S",
)


def _parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    for fmt in ISO_FORMATS:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:  # pragma: no cover - loop attempts
            continue
    raise ValueError(f"Unsupported datetime format: {value}")


@dataclass(slots=True)
class HubSpotAccountAdapter:
    payload: dict[str, Any]

    def to_account(self) -> Account:
        return Account(
            id=f"hubspot::{self.payload["account_id"]}",
            name=self.payload["account_name"],
            domain=(self.payload.get("company_domain") or "").lower() or None,
            segment=self.payload.get("segment"),
            arr=float(self.payload.get("arr") or 0.0) or None,
            owner=self.payload.get("owner_email"),
            last_touch=_parse_datetime(self.payload.get("hubspot_last_touch")),
            source_systems=["hubspot"],
        )


@dataclass(slots=True)
class SalesforceAccountAdapter:
    payload: dict[str, Any]

    def to_account(self) -> Account:
        return Account(
            id=f"salesforce::{self.payload["Id"]}",
            name=self.payload["AccountName"],
            domain=(self.payload.get("Website") or "").lower() or None,
            segment=self.payload.get("Industry"),
            arr=float(self.payload.get("ARR__c") or 0.0) or None,
            owner=self.payload.get("Owner"),
            last_touch=_parse_datetime(self.payload.get("LastActivityDate")),
            source_systems=["salesforce"],
        )


@dataclass(slots=True)
class PipedriveDealAdapter:
    payload: dict[str, Any]

    def to_deal(self, account_id: str) -> Deal:
        return Deal(
            id=f"pipedrive::{self.payload["deal_id"]}",
            account_id=account_id,
            amount=float(self.payload.get("value") or 0.0),
            stage=self.payload.get("status", "open"),
            source_system="pipedrive",
            expected_close=_parse_datetime(self.payload.get("expected_close")),
        )


@dataclass(slots=True)
class ActivityAdapter:
    payload: dict[str, Any]

    def to_activity(self, account_id: str) -> Activity:
        return Activity(
            id=f"activity::{self.payload["source"]}::{self.payload["timestamp"]}::{self.payload["account_name"].lower()}",
            account_id=account_id,
            contact_email=self.payload.get("contact_email"),
            kind=self.payload.get("kind", "email"),
            occurred_at=_parse_datetime(self.payload.get("timestamp"))
            or datetime.now(timezone.utc),
            source_system=self.payload.get("source", "unknown"),
            metadata={"notes": self.payload.get("notes", "")},
        )
