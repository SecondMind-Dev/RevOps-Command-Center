from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timezone

from ..scoring.pipeline import Scorecard
from .workflows import AutomationEvent


@dataclass(slots=True)
class TriggerConfig:
    hot_threshold: float = 0.6
    warm_threshold: float = 0.3


def build_events(
    scorecard: Scorecard,
    config: TriggerConfig | None = None,
    *,
    timestamp: datetime | None = None,
) -> Iterable[AutomationEvent]:
    config = config or TriggerConfig()
    event_time = timestamp or datetime.now(timezone.utc)

    for snapshot in scorecard.snapshots:
        payload = {
            "account": snapshot.account.name,
            "owner": snapshot.account.owner or "unknown",
            "score": str(snapshot.score),
            "label": snapshot.label,
        }

        if snapshot.score >= config.hot_threshold:
            yield AutomationEvent(
                entity_id=snapshot.account.id,
                event_type="hot_account_alert",
                payload={
                    **payload,
                    "subject": f"🔥 Hot account: {snapshot.account.name}",
                    "recipient": snapshot.account.owner or "revops@secondmind.dev",
                },
                created_at=event_time,
            )
        elif snapshot.score >= config.warm_threshold:
            yield AutomationEvent(
                entity_id=snapshot.account.id,
                event_type="warm_account_digest",
                payload=payload,
                created_at=event_time,
            )
