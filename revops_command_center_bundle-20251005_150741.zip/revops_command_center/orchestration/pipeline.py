from __future__ import annotations

import json
import os
import shutil
import time
import zipfile
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..docs.digests.email import DigestGenerator
from ..docs.playbooks import templates as playbook_templates
from .automations import triggers, workflows
from .ingestion import loader
from .mission_log import MissionWriter
from .scoring import pipeline as scoring_pipeline

LOG_PATH = Path(__file__).resolve().parents[1] / "automation_log.jsonl"
PLAYBOOK_DIR = loader.DATA_DIR.parent / "docs" / "playbooks" / "generated"
DIGEST_DIR = loader.DATA_DIR.parent / "docs" / "digests" / "generated"
BUNDLE_DIR = loader.DATA_DIR.parent / "docs" / "bundles"
PAYLOAD_CACHE_PATH = BUNDLE_DIR / "latest_payload.json"


@dataclass(slots=True)
class OrchestrationResult:
    scorecard: scoring_pipeline.Scorecard
    mission_log: workflows.MissionLog
    digest_text: str
    digest_path: Path
    playbooks: list[dict[str, Any]]
    generated_at: datetime
    kpis: dict[str, Any]
    bundle_path: Path
    top_accounts: list[dict[str, Any]]


def run_orchestration() -> OrchestrationResult:
    freeze_ts = os.getenv("REVOPS_FREEZE_TIMESTAMP")
    if freeze_ts:
        generated_at = datetime.fromisoformat(freeze_ts).astimezone(timezone.utc)
    else:
        generated_at = datetime.now(timezone.utc)

    variation_disabled = _variation_disabled()
    variation_seed = None if variation_disabled else _derive_variation_seed()

    graph = loader.load_bundle()
    engine = scoring_pipeline.ScoringEngine(
        jitter_strength=0.08 if variation_seed is not None else 0.0,
        variation_seed=variation_seed,
    )
    scorecard = scoring_pipeline.build_scorecard(graph, engine=engine)

    runner = workflows.default_runner()
    events = list(triggers.build_events(scorecard, timestamp=generated_at))
    runner.dispatch(events)

    if events:
        MissionWriter(log_path=LOG_PATH).append(
            events, timestamp=generated_at.isoformat()
        )

    playbook_templates.PlaybookGenerator(output_dir=PLAYBOOK_DIR).render(scorecard)
    digest_path = DigestGenerator(output_dir=DIGEST_DIR).render(
        scorecard,
        generated_at=generated_at,
    )
    digest_text = digest_path.read_text(encoding="utf-8")

    playbooks: list[dict[str, Any]] = [
        {
            "name": path.stem.replace("_", " ").title(),
            "path": str(path.resolve()),
            "content": path.read_text(encoding="utf-8"),
        }
        for path in sorted(PLAYBOOK_DIR.glob("*.md"))
    ]

    snapshots = scorecard.snapshots
    total_accounts = len(snapshots)
    hot_count = sum(1 for snap in snapshots if snap.label == "Hot")
    warm_count = sum(1 for snap in snapshots if snap.label == "Warm")
    kpis: dict[str, Any] = {
        "total_accounts": total_accounts,
        "hot_accounts": hot_count,
        "warm_accounts": warm_count,
        "automation_events": len(runner.mission_log.entries),
        "summary_length": len(digest_text.strip()),
    }

    top_accounts_full = [
        {
            "id": snap.account.id,
            "name": snap.account.name,
            "score": snap.score,
            "label": snap.label,
            "owner": snap.account.owner,
        }
        for snap in scorecard.top_accounts(10)
    ]
    top_accounts_display = top_accounts_full[:5]

    bundle_path, summary_payload = _build_artifact_bundle(
        digest_path=digest_path,
        playbooks=[Path(pb["path"]) for pb in playbooks],
        mission_log_path=LOG_PATH,
        kpis=kpis,
        top_accounts=top_accounts_full,
        mission_entries=runner.mission_log.entries,
        generated_at=generated_at,
    )

    payload = build_dashboard_payload_from_parts(
        top_accounts=top_accounts_display,
        mission_log_entries=runner.mission_log.entries,
        playbooks=playbooks,
        digest_path=digest_path,
        digest_text=digest_text,
        kpis=kpis,
        bundle_path=bundle_path,
        generated_at=generated_at,
    )
    cache_payload(payload)

    return OrchestrationResult(
        scorecard=scorecard,
        mission_log=runner.mission_log,
        digest_text=digest_text,
        digest_path=digest_path,
        playbooks=playbooks,
        generated_at=generated_at,
        kpis=kpis,
        bundle_path=bundle_path,
        top_accounts=top_accounts_display,
    )


def _build_artifact_bundle(
    *,
    digest_path: Path,
    playbooks: list[Path],
    mission_log_path: Path,
    kpis: dict[str, Any],
    top_accounts: list[dict[str, Any]],
    mission_entries: list[str],
    generated_at: datetime,
) -> tuple[Path, dict[str, Any]]:
    BUNDLE_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = generated_at.strftime("%Y%m%d_%H%M%S")
    bundle_path = BUNDLE_DIR / f"revops_bundle_{timestamp}.zip"

    summary_payload = {
        "generated_at": generated_at.isoformat(),
        "kpis": kpis,
        "top_accounts": top_accounts,
        "mission_entries": mission_entries,
        "digest_file": digest_path.name,
        "artifact_bundle": f"revops_bundle_{timestamp}.zip",
        "playbooks": [pb.name for pb in playbooks],
    }

    with zipfile.ZipFile(
        bundle_path, mode="w", compression=zipfile.ZIP_DEFLATED
    ) as bundle:
        if digest_path.exists():
            bundle.write(digest_path, arcname=f"digest/{digest_path.name}")

        for pb_path in playbooks:
            if pb_path.exists():
                bundle.write(pb_path, arcname=f"playbooks/{pb_path.name}")

        if mission_log_path.exists():
            bundle.write(mission_log_path, arcname=f"logs/{mission_log_path.name}")

        bundle.writestr("summary.json", json.dumps(summary_payload, indent=2))

    latest_path = BUNDLE_DIR / "latest.zip"
    shutil.copyfile(bundle_path, latest_path)
    return latest_path, summary_payload


def build_dashboard_payload(result: OrchestrationResult) -> dict[str, Any]:
    return build_dashboard_payload_from_parts(
        top_accounts=result.top_accounts,
        mission_log_entries=result.mission_log.entries,
        playbooks=result.playbooks,
        digest_path=result.digest_path,
        digest_text=result.digest_text,
        kpis=result.kpis,
        bundle_path=result.bundle_path,
        generated_at=result.generated_at,
    )


def build_dashboard_payload_from_parts(
    *,
    top_accounts: list[dict[str, Any]],
    mission_log_entries: list[str],
    playbooks: list[dict[str, Any]],
    digest_path: Path,
    digest_text: str,
    kpis: dict[str, Any],
    bundle_path: Path,
    generated_at: datetime,
) -> dict[str, Any]:
    return {
        "top_accounts": top_accounts,
        "mission_log_entries": mission_log_entries,
        "playbooks": playbooks,
        "digest": {
            "text": digest_text,
            "path": str(digest_path.resolve()),
            "generated_at": generated_at.isoformat(),
        },
        "kpis": kpis,
        "artifact_bundle": str(bundle_path.resolve()),
    }


def cache_payload(payload: dict[str, Any]) -> None:
    BUNDLE_DIR.mkdir(parents=True, exist_ok=True)
    PAYLOAD_CACHE_PATH.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def load_cached_payload() -> dict[str, Any] | None:
    if not PAYLOAD_CACHE_PATH.exists():
        return None
    payload = json.loads(PAYLOAD_CACHE_PATH.read_text(encoding="utf-8"))
    return payload


def _variation_disabled() -> bool:
    flag = os.getenv("REVOPS_DISABLE_VARIATION", "").strip().lower()
    return flag in {"1", "true", "yes", "on"}


def _derive_variation_seed() -> int:
    env_seed = os.getenv("REVOPS_VARIATION_SEED")
    if env_seed:
        try:
            return int(env_seed)
        except ValueError:
            pass
    # time_ns keeps seeds unique per capture while remaining deterministic within the run
    return time.time_ns() & ((1 << 63) - 1)
