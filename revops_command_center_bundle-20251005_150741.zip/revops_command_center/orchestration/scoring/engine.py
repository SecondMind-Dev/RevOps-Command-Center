"""Signal scoring engine."""

from __future__ import annotations

from dataclasses import dataclass
import random
from datetime import datetime, timezone

from ..normalization.merge import CanonicalGraph
from ..normalization.schema import Account

NOW = datetime(2025, 10, 4, tzinfo=timezone.utc)
LOOKBACK_DAYS = 30


@dataclass(slots=True)
class ScoringSnapshot:
    account: Account
    score: float
    signals: dict[str, float]
    label: str


@dataclass(slots=True)
class ScoringEngine:
    recency_weight: float = 0.5
    fit_weight: float = 0.3
    engagement_weight: float = 0.2
    jitter_strength: float = 0.0
    variation_seed: int | None = None

    def score_graph(self, graph: CanonicalGraph) -> list[ScoringSnapshot]:
        snapshots: list[ScoringSnapshot] = []

        activity_counts: dict[str, int] = _count_recent_activities(graph)
        rng: random.Random | None = None
        if self.jitter_strength > 0 and self.variation_seed is not None:
            rng = random.Random(self.variation_seed)

        for account in graph.accounts:
            recency_signal = _recency_signal(account.last_touch)
            fit_signal = _fit_signal(account.arr)
            engagement_signal = (
                activity_counts.get(account.id, 0) / 5
            )  # normalize by 5 events

            score = (
                recency_signal * self.recency_weight
                + fit_signal * self.fit_weight
                + engagement_signal * self.engagement_weight
            )

            if rng is not None:
                jitter = rng.uniform(-self.jitter_strength, self.jitter_strength)
                score = max(0.0, min(1.0, score + jitter))

            label = _label_for_score(score)
            snapshots.append(
                ScoringSnapshot(
                    account=account,
                    score=round(score, 3),
                    signals={
                        "recency": round(recency_signal, 3),
                        "fit": round(fit_signal, 3),
                        "engagement": round(engagement_signal, 3),
                    },
                    label=label,
                )
            )

        snapshots.sort(key=lambda snap: snap.score, reverse=True)
        return snapshots


def _recency_signal(last_touch: datetime | None) -> float:
    if not last_touch:
        return 0.0
    delta = NOW - last_touch
    days = max(delta.days, 0)
    if days <= LOOKBACK_DAYS:
        return 1 - (days / LOOKBACK_DAYS)
    return 0.0


def _fit_signal(arr: float | None) -> float:
    if not arr or arr <= 0:
        return 0.0
    # normalize relative to $500k target
    capped = min(arr, 500_000)
    return capped / 500_000


def _count_recent_activities(graph: CanonicalGraph) -> dict[str, int]:
    counts: dict[str, int] = {}
    for activity in graph.activities:
        delta = NOW - activity.occurred_at
        if delta.days <= LOOKBACK_DAYS:
            counts[activity.account_id] = counts.get(activity.account_id, 0) + 1
    return counts


def _label_for_score(score: float) -> str:
    if score >= 0.75:
        return "Hot"
    if score >= 0.4:
        return "Warm"
    return "Monitor"
