from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from typing import Iterable

from .schema import Account, Activity, Deal


def _key_from_account(account: Account) -> str:
    if account.domain:
        return account.domain.lower()
    return account.name.strip().lower()


@dataclass(slots=True)
class CanonicalGraph:
    accounts: list[Account]
    deals: list[Deal] = field(default_factory=list)
    activities: list[Activity] = field(default_factory=list)
    domain_index: dict[str, str] = field(default_factory=dict)

    def attach_related(
        self,
        *,
        deals: dict[str, list[Deal]] | None = None,
        activities: dict[str, list[Activity]] | None = None,
    ) -> None:
        deals = deals or {}
        activities = activities or {}
        for account in self.accounts:
            account_deals = deals.get(account.id, [])
            if account_deals:
                total_open = sum(d.amount for d in account_deals if d.stage != "won")
                account.open_deals_value = total_open
                self.deals.extend(account_deals)

            account_activities = activities.get(account.id, [])
            if account_activities:
                if account.last_touch is None:
                    account.last_touch = max(a.occurred_at for a in account_activities)
                self.activities.extend(account_activities)


def build_canonical_graph(accounts: Iterable[Account]) -> CanonicalGraph:
    grouped: dict[str, list[Account]] = defaultdict(list)
    for account in accounts:
        key = _key_from_account(account)
        grouped[key].append(account)

    canonical_accounts: list[Account] = []
    domain_index: dict[str, str] = {}

    for key, account_variants in grouped.items():
        merged = _merge_accounts(account_variants)
        canonical_accounts.append(merged)
        domain_index[key] = merged.id
        if merged.domain:
            domain_index[merged.domain.lower()] = merged.id
            domain_index[merged.name.strip().lower()] = merged.id

    return CanonicalGraph(accounts=canonical_accounts, domain_index=domain_index)


def _merge_accounts(accounts: list[Account]) -> Account:
    base = accounts[0].model_copy()
    base.source_systems = sorted(
        {source for acc in accounts for source in acc.source_systems}
    )

    arr_candidates = [acc.arr for acc in accounts if acc.arr]
    if arr_candidates:
        base.arr = max(arr_candidates)

    owners = [acc.owner for acc in accounts if acc.owner]
    if owners:
        base.owner = owners[0]

    segments = [acc.segment for acc in accounts if acc.segment]
    if segments:
        base.segment = segments[0]

    touches = [acc.last_touch for acc in accounts if acc.last_touch]
    if touches:
        base.last_touch = max(touches, key=lambda dt: dt if dt else datetime.min)

    return base
