from __future__ import annotations

from fastapi import APIRouter

from revops_command_center.orchestration import pipeline

router = APIRouter(prefix="/tasks", tags=["tasks"])


@router.get("/")
async def list_tasks() -> list[dict[str, str | float]]:
    result = pipeline.run_orchestration()
    tasks = []
    for snap in result.scorecard.snapshots:
        tasks.append(
            {
                "account": snap.account.name,
                "owner": snap.account.owner,
                "score": snap.score,
                "label": snap.label,
            }
        )
    return tasks
