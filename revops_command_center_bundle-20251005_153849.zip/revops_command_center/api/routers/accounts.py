from __future__ import annotations

from fastapi import APIRouter

router = APIRouter(prefix="/accounts", tags=["accounts"])


@router.get("/")
async def list_accounts() -> list[dict[str, str]]:  # pragma: no cover - stub
    return []
