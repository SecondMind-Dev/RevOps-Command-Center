"""Lightweight websocket fanout for dashboard refresh events."""

from __future__ import annotations

from contextlib import suppress
from typing import Any

from fastapi import WebSocket, WebSocketDisconnect


class DashboardConnectionManager:
    def __init__(self) -> None:
        self._connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket) -> None:
        await websocket.accept()
        self._connections.append(websocket)

    def disconnect(self, websocket: WebSocket) -> None:
        if websocket in self._connections:
            self._connections.remove(websocket)

    async def broadcast(self, payload: dict[str, Any]) -> None:
        dead: list[WebSocket] = []
        for websocket in list(self._connections):
            with suppress(Exception):
                await websocket.send_json(payload)
                continue
            dead.append(websocket)
        for websocket in dead:
            self.disconnect(websocket)

    async def listen(self, websocket: WebSocket) -> None:
        try:
            while True:
                await websocket.receive_text()
        except WebSocketDisconnect:
            self.disconnect(websocket)


manager = DashboardConnectionManager()
