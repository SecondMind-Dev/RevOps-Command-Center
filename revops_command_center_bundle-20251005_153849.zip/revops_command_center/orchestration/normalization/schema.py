"""Canonical data models for the RevOps Command Center."""

from __future__ import annotations

from datetime import datetime
from typing import Sequence

from pydantic import BaseModel, Field


class Account(BaseModel):
    id: str
    name: str
    domain: str | None = None
    segment: str | None = None
    arr: float | None = None
    owner: str | None = None
    last_touch: datetime | None = None
    source_systems: Sequence[str] = Field(default_factory=list)
    open_deals_value: float = 0.0


class Contact(BaseModel):
    id: str
    account_id: str
    email: str
    title: str | None = None
    last_engaged: datetime | None = None
    source_system: str | None = None


class Deal(BaseModel):
    id: str
    account_id: str
    amount: float
    stage: str
    source_system: str
    expected_close: datetime | None = None


class Activity(BaseModel):
    id: str
    account_id: str
    contact_email: str | None = None
    kind: str = Field(..., description="call|email|meeting|usage|support")
    occurred_at: datetime
    source_system: str
    metadata: dict[str, str] = Field(default_factory=dict)
