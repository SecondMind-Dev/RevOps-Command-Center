from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Iterable, Protocol


@dataclass(slots=True)
class AutomationEvent:
    entity_id: str
    event_type: str
    payload: dict[str, str]
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


class Notifier(Protocol):
    def send(self, event: AutomationEvent) -> None:  # pragma: no cover - interface
        ...


@dataclass(slots=True)
class SlackNotifier:
    channel: str = "#revops-alerts"

    def send(self, event: AutomationEvent) -> None:  # pragma: no cover - logging stub
        print(f"[SLACK:{self.channel}] {event.event_type} -> {event.payload}")


@dataclass(slots=True)
class EmailNotifier:
    sender: str = "revops-command@secondmind.dev"

    def send(self, event: AutomationEvent) -> None:  # pragma: no cover - logging stub
        recipient = event.payload.get("recipient", "revops@secondmind.dev")
        subject = event.payload.get("subject", event.event_type)
        print(f"[EMAIL:{self.sender}->{recipient}] {subject}")


@dataclass(slots=True)
class MissionLog:
    entries: list[str] = field(default_factory=list)

    def append(self, event: AutomationEvent) -> None:
        summary = f"{event.created_at.isoformat()} | {event.event_type} | {event.entity_id} | {event.payload}"
        self.entries.append(summary)


@dataclass(slots=True)
class AutomationRunner:
    notifiers: list[Notifier]
    mission_log: MissionLog

    def dispatch(self, events: Iterable[AutomationEvent]) -> None:
        for event in events:
            self.mission_log.append(event)
            for notifier in self.notifiers:
                notifier.send(event)


def default_runner() -> AutomationRunner:
    return AutomationRunner(
        notifiers=[SlackNotifier(), EmailNotifier()], mission_log=MissionLog()
    )
