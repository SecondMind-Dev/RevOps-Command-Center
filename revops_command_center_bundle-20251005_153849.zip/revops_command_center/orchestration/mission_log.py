from __future__ import annotations

import json
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .automations.workflows import AutomationEvent


@dataclass(slots=True)
class MissionWriter:
    log_path: Path

    def append(
        self, events: Iterable[AutomationEvent], *, timestamp: str | None = None
    ) -> None:
        ts = timestamp or datetime.now(timezone.utc).isoformat()
        for event in events:
            entry = {
                "timestamp": ts,
                "event_type": event.event_type,
                "entity_id": event.entity_id,
                "payload": event.payload,
            }
            data = json.dumps(entry)
            self.log_path.parent.mkdir(parents=True, exist_ok=True)
            with self.log_path.open("a") as handle:
                handle.write(data + "\n")


@dataclass(slots=True)
class MissionReader:
    log_path: Path

    def tail(self, limit: int = 20) -> list[str]:
        if not self.log_path.exists():
            return []
        with self.log_path.open() as handle:
            lines = handle.readlines()
        return [line.strip() for line in lines[-limit:]]
