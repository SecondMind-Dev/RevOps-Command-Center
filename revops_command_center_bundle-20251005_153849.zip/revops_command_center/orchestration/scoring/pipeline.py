from __future__ import annotations

from dataclasses import dataclass

from ..normalization.merge import CanonicalGraph
from .engine import ScoringEngine, ScoringSnapshot


@dataclass(slots=True)
class Scorecard:
    graph: CanonicalGraph
    snapshots: list[ScoringSnapshot]

    def top_accounts(self, limit: int = 5) -> list[ScoringSnapshot]:
        return self.snapshots[:limit]


def build_scorecard(
    graph: CanonicalGraph, *, engine: ScoringEngine | None = None
) -> Scorecard:
    engine = engine or ScoringEngine()
    snapshots = engine.score_graph(graph)
    return Scorecard(graph=graph, snapshots=snapshots)
