// Placeholder load function for SSR – optional.
export const ssr = false;
