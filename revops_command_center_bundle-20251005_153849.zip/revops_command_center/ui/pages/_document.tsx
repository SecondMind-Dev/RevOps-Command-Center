import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html lang="en">
      <Head />
      <body
        style={{
          margin: 0,
          minHeight: "100%",
          backgroundColor: "#050508",
        }}
      >
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
