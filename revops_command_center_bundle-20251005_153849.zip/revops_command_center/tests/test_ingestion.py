from __future__ import annotations

from revops_command_center.orchestration.ingestion import loader


def test_load_bundle_returns_graph() -> None:
    graph = loader.load_bundle()
    domains = sorted(acc.domain for acc in graph.accounts)
    assert any(domain == "atlasforge.io" for domain in domains)
    assert len(graph.accounts) == 3  # atlasforge, nebulaworks, zenify
    atlas = next(acc for acc in graph.accounts if acc.domain == "atlasforge.io")
    assert atlas.source_systems == ["hubspot", "salesforce"]
    assert graph.deals  # deals attached
    assert graph.activities  # activities attached
