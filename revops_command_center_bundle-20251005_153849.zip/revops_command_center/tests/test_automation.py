from __future__ import annotations

from pathlib import Path

from revops_command_center.orchestration import pipeline


def test_orchestration_runs() -> None:
    result = pipeline.run_orchestration()
    assert result.scorecard.snapshots
    assert result.mission_log.entries
    assert result.digest_path.exists()
    assert result.digest_path.read_text().strip()  # digest content not empty
