from __future__ import annotations

from revops_command_center.orchestration.ingestion import loader
from revops_command_center.orchestration.scoring import pipeline


def test_scorecard_orders_accounts() -> None:
    graph = loader.load_bundle()
    scorecard = pipeline.build_scorecard(graph)
    assert scorecard.snapshots
    scores = [snap.score for snap in scorecard.snapshots]
    assert scores == sorted(scores, reverse=True)
    top_label = scorecard.snapshots[0].label
    assert top_label in {"Hot", "Warm", "Monitor"}
