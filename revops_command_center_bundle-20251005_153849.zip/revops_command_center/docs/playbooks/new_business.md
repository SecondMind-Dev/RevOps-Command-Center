
# New Business Playbook (Draft)

- Placeholder content. This doc will be auto-generated from canonical data in the full build.
