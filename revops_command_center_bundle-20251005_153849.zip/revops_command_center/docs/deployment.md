# RevOps Command Center — Deployment Notes (Draft)

## Local Dev

### API
1. Create a virtualenv and install requirements:
   ```bash
   pip install fastapi uvicorn
   ```
2. Run the orchestration API with CORS support:
   ```bash
   PYTHONPATH=. uvicorn revops_command_center.api.mock_server:app --reload --port 8000
   ```
   The mock server wraps the FastAPI app and enables cross-origin calls from the dashboard.

### Dashboard
1. Navigate to `revops_command_center/ui`.
2. Install dependencies (Node 18+):
   ```bash
   npm install
   ```
3. Start the UI dev server (expects API at `http://localhost:8000`):
   ```bash
   npm run dev
   ```

## Demo Artifact Refresh
- Generate the latest playbooks/digest/mission log snapshot:
  ```bash
  PYTHONPATH=. python -m revops_command_center.scripts.preview_digest
  ```
- Capture API payloads for the portfolio:
  ```bash
  PYTHONPATH=. python -m revops_command_center.scripts.record_dashboard_demo
  ```

## Production Sketch (when ready)
- Containerize API + orchestrator with `uvicorn` and schedule `pipeline.run_orchestration()` on Celery/Prefect or a cron job.
- Host the Svelte/Next UI as static assets behind Vercel/Netlify, pointing to the deployed API.
- Store mission log + digest outputs in S3 or a managed blob store; expose them via the UI for downloads.
- Replace sample CSV ingestion with live CRM adapters (HubSpot/Salesforce/Pipedrive REST) using API keys stored in a secrets manager.

## Monitoring
- Tail `automation_log.jsonl` for a quick check (`tail -f automation_log.jsonl`).
- Wire the mission log into your logging platform (e.g., Datadog) once deployed.
- Promote the digest email via an automation service (SendGrid/Postmark) using the generated text.
