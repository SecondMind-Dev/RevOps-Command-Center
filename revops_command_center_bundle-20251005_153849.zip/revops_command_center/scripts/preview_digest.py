from __future__ import annotations

from pathlib import Path

from revops_command_center.orchestration import pipeline


def main() -> None:
    result = pipeline.run_orchestration()
    digest_path = result.digest_path
    print(f"Digest generated at {digest_path}")
    print("\n===== Digest Preview =====\n")
    print(digest_path.read_text())


if __name__ == "__main__":
    main()
